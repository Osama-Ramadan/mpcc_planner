# Weekly Reports

To keep a constant flow of information about your thesis status and to help you keeping an overview of your progress please sent on Monday a weekly report answering the following questions:

1. What have you *achieved* last week and compared to what you have planned?
2. What do you *plan* to do this week?
3. What is your progress related to the tasks in the project description?
4. Questions for yourself and for me?

The report can be plain text and just keywords or you write some text or you submit a few pictures or videos. The form and way is left open. Please paste the report in this issue.

## Progress

* [ ] First week
* [ ] Second week (Needs to be adjusted, when creating the issue)