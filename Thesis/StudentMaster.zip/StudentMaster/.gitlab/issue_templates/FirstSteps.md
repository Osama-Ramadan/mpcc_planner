# First Steps

## Preparation

- [ ] Familiarization with git
- [ ] Setup Latex for thesis and presentation template
  - Best is to use lualatex and biber for bibliographie
  - lualatex.exe -synctex=1 -interaction=nonstopmode --enable-write18 -interaction=nonstopmode %.tex
  - and for *.bib files you have to use biber
  - a latexmk file is not provided yet.
- [ ] Draft Project description
  - Think about the project
  - Read about the project related topics (Own and provided material)
  - Draft project description in thesis/admin/project_description.tex
  - Enter tasks which are related to milestones and guide you through your work

## Familiarization phase
